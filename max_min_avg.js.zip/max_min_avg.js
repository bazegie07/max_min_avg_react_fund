function maxminavg(arr){
    var max = 0;
    var min = 0;
    var sum = 0;
    for(var i = 0; i < arr.length; i++){
        if(arr[i] > max){
            max = arr[i];
        }
        if(arr[i] < min){
            min = arr[i];
        }
        sum = sum + arr[i];
    }
    var avg = sum / arr.length;
    return "The minimum is" + min +  "the maximum is "+ max + " and the average is " + avg
}
y = maxminavg([1,-2,9,4])
console.log(y);